// What every app's vite.config.ts needs from the core: theme-boot.js at /theme-boot.js, served in dev and put in the
// build, so index.html loads the core's copy and no app keeps one of its own (the two apps' copies had drifted: the
// accent list, the old "mind-gym.look" key).
//
//   import { organon } from '@organon/core/vite';
//   export default defineConfig({ plugins: [svelte(), organon()] });

import { readFileSync } from 'node:fs';
import type { Plugin } from 'vite';

const BOOT = new URL('../src/ui/theme-boot.js', import.meta.url);

export function organon(): Plugin {
  const boot = () => readFileSync(BOOT, 'utf8');
  return {
    name: 'organon',
    configureServer(server) {
      server.middlewares.use('/theme-boot.js', (_req, res) => {
        res.setHeader('Content-Type', 'text/javascript; charset=utf-8');
        res.end(boot());
      });
    },
    generateBundle() {
      this.emitFile({ type: 'asset', fileName: 'theme-boot.js', source: boot() });
    },
  };
}
